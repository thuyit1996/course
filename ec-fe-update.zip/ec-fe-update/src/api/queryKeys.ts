export const QueryKeys = {
    getAllTopic: 'GET_ALL_TOPIC',
    getAllAdminTopic: 'GET_ALL_ADMIN_TOPIC',
    getAllClass: 'GET_ALL_CLASS'
}