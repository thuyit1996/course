'use server';

import { ResponseData } from "@/types/api";
import { WritingFeedback } from "@/types/exam";
import { submitWritingTest } from "./fetches";