export const Cookiekeys = {
    accessToken: 'accessToken',
  };
  